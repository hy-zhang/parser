ruby computePositions.rb
pdflatex paper.tex
bibtex paper
pdflatex paper.tex
pdflatex paper.tex
